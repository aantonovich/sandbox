/**
 * Contains functions that are added to the root AngularJs scope.
 */
angular.module('crudApp').run(function($rootScope, Auth, AUTH_EVENTS) {

    //before each state change, check if the user is logged in
    //and authorized to move onto the next state
    $rootScope.$on('$routeChangeStart', function (event, next) {
        if (next.data) {
            var authorizedRoles = next.data.authorizedRoles;
            if (!Auth.isAuthorized(authorizedRoles)) {
                event.preventDefault();
                if (Auth.isAuthenticated()) {
                    // user is not allowed
                    $rootScope.$broadcast(AUTH_EVENTS.notAuthorized);
                } else {
                    // user is not logged in
                    $rootScope.$broadcast(AUTH_EVENTS.notAuthenticated);
                }
            }
        }
    });

    $rootScope.logout = function(){
        Auth.logout();
    };

});