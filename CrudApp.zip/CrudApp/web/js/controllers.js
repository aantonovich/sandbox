angular.module('crudApp.controllers', [])
    .controller('MenuCtrl', function ($rootScope, $scope, $location, groupSvc, queryByGroupSvc, Auth, $q, USER_ROLES, AUTH_EVENTS) {
        $scope.generateMenu = function () {
            $scope.menuItems = [];
            var index = 0;

            if (Auth.isAuthorized(USER_ROLES.developer)) {
                initMenuForRole(index++, 'Developer', 'DEVELOPER');
            }
            if (Auth.isAuthorized(USER_ROLES.user)) {
                initMenuForRole(index++, 'User', 'USER');
            }

            if (Auth.isAuthorized(USER_ROLES.admin)) {
                initMenuForRole(index++, 'Administrator', 'ADMIN');
            }

            function initMenuForRole(index, label, role) {
                $scope.menuItems[index] = {
                    display: label, href: '#', children: [
                        {display: 'Query Groups', href: '#', children: []}
                    ]
                };
                var queryGroupsMenuItem = $scope.menuItems[index].children[0];
                var groupMenuItem = {display: 'Create new query', href: '#/query/0', children: []};
                $scope.menuItems[index].children.push(groupMenuItem);

                groupSvc.query({'role': role}, function (groups) {
                    groups.forEach(function (group) {
                        var groupMenuItem = {display: group.groupName, href: '#', children: []};
                        queryGroupsMenuItem.children.push(groupMenuItem);

                        queryByGroupSvc.query({'groupId': group.groupId}, function (queries) {
                            queries.forEach(function (query) {
                                var queryMenuItem = {
                                    display: query.queryName,
                                    href: '#/query-request-list/' + query.queryId,
                                    children: []
                                };
                                groupMenuItem.children.push(queryMenuItem);
                            });
                        });
                        var queryMenuItem = {
                            display: 'View all queries',
                            href: '#/list/' + group.groupId,
                            children: []
                        };
                        groupMenuItem.children.push(queryMenuItem);
                    });

                });
            }

            $scope.menuItems[index++] = {display: 'Help', href: '#', children: []};
        }

        $scope.generateMenu();
        //listen to events of unsuccessful logins, to run the login dialog
        $rootScope.$on(AUTH_EVENTS.notAuthorized, $scope.generateMenu);
        $rootScope.$on(AUTH_EVENTS.notAuthenticated, $scope.generateMenu);
        $rootScope.$on(AUTH_EVENTS.sessionTimeout, $scope.generateMenu);
        $rootScope.$on(AUTH_EVENTS.logoutSuccess, $scope.generateMenu);
        $rootScope.$on(AUTH_EVENTS.loginSuccess, $scope.generateMenu);
    })
    .controller('ListCtrl', function ($scope, $location, $routeParams, queryByGroupSvc) {

        queryByGroupSvc.query({'groupId' : $routeParams.groupId}).$promise.then(function (queries) {
            $scope.queries = queries;
        });

        $scope.createRequest = function (queryId) {
            $location.path('/request-detail/' + queryId + '/0');
        };

        $scope.viewRequests = function (queryId) {
            $location.path('/query-request-list/' + queryId);
        };

        $scope.editQuery = function (queryId) {
            $location.path('/query/' + queryId);
        };

        $scope.createQuery = function () {
            $location.path('/query/0');
        };
    })
    .controller('ListQueriesRequestsCtrl', function ($scope, $location, $route, queryrequestSvc, querySvc, $routeParams) {
        $scope.queryId = $routeParams.queryId;
        $scope.query = querySvc.get({id: $scope.queryId});

        $scope.queriesrequests = queryrequestSvc.query({'queryId': $scope.queryId});

        $scope.resubmitRequest = function (requestId) {
            $location.path('/request-detail/' + $scope.queryId + '/' + requestId);
        };

        $scope.submitNewRequest = function () {
            $location.path('/request-detail/' + $scope.queryId + '/0');
        };

    })
    .controller('EditRequestCtrl', function ($scope, $location, requestSvc, querycolumnsSvc, querySvc, Session, $routeParams, AUTH_EVENTS, $rootScope) {

        function initColumnsAndFilters() {
            for (var i = 0; i < $scope.allColumns.length; i++) {
                var column = $scope.allColumns[i];
                for (var j = 0; j < $scope.request.requestColumns.length; j++) {
                    var columnFromRequest = $scope.request.requestColumns[j];
                    if (columnFromRequest.columnName == column.columnName) {
                        column.used = columnFromRequest.used;
                        column.operation = columnFromRequest.operation;
                        column.filterValue1 = columnFromRequest.filterValue1;
                        column.filterValue2 = columnFromRequest.filterValue2;
                    }
                }
            }
        }

        function initRequest() {
            querycolumnsSvc.query({id: $scope.request.queryId})
                .$promise.then(function (queryColumns) {
                $scope.allColumns = queryColumns;
                initColumnsAndFilters();
            });

            querySvc.get({id: $scope.request.queryId})
                .$promise.then(function (query) {
                $scope.query = query;
            });

            if (Session.user) {
                $scope.request.userName = Session.user.username;
            } else {
                $rootScope.$on(AUTH_EVENTS.loginSuccess, setCurrentUser);
            }
        }

        function setCurrentUser() {
            $scope.request.userName = $rootScope.currentUser.username;
        }

        // this controller handles insert and update pages
        $scope.editMode = ($routeParams.requestId !== "0");

        if ($scope.editMode) {
            requestSvc.get({requestId: $routeParams.requestId})
                .$promise.then(function (request) {
                $scope.request = request;
                initRequest();
            });
        } else {
            $scope.request = new requestSvc();
            $scope.request.queryId = $routeParams.queryId;
            $scope.request.requestColumns = [];
            initRequest();
        }

        /* callback for ng-click 'updateRequest': */
        $scope.submitRequest = function () {
            var request = $scope.request;
            request.requestColumns = [];

            for (var i = 0; i < $scope.allColumns.length; i++) {
                var column = $scope.allColumns[i];
                if (column.used || column.operation) {
                    var columnFromRequest = {
                        columnName: column.columnName,
                        used: column.used,
                        operation: column.operation,
                        filterValue1: column.filterValue1,
                        filterValue2: column.filterValue2
                    };
                    request.requestColumns.push(columnFromRequest);
                }
            }

            request.$save(function (data) {
                alert("Request has been re-submitted successfully.");
                $location.path('/query-request-list');
            }, function (err) {
                alert('Request could not be resubmitted... Please check your selections and resubmit again... Thank you.');
            });
        };

        /* callback for ng-click 'cancel': */
        $scope.cancel = function () {
            $location.path('/query-request-list');
        };

    })
    .controller('EditQueryCtrl', function ($scope, $location, querySvc, groupSvc, Session, $routeParams, $uibModal) {
        $scope.querySvc = querySvc;

        groupSvc.query({'role': Session.userRole}).$promise.then(function (groups) {
            $scope.groups = groups;
        });

        // this controller handles insert and update pages
        $scope.editMode = ($routeParams.id !== "0");
        if ($scope.editMode) {
            $scope.query = querySvc.get({id: $routeParams.id});
        } else {
            $scope.query = new querySvc();
        }

        /* callback for ng-click 'updateQuery': */
        $scope.verifyQuery = function () {
            var query = $scope.query;
            $scope.querySvc.verify({}, query, function (columns) {
                var verifyModalInstance = $uibModal.open({
                    templateUrl: 'partials/verify-query-modal.html',
                    controller: 'VerifyModalInstanceCtrl',
                    size: 'lg',
                    resolve: {
                        columns: function () {
                            return columns;
                        },
                        query: function () {
                            return $scope.query;
                        },
                        editMode: function () {
                            return $scope.editMode;
                        }
                    }
                });
            }, function (err) {
                alert('request failed, please correct your query');
            });
        };

        /* callback for ng-click 'cancel': */
        $scope.cancel = function () {
            $location.path('#');
        };

    })
    .controller('VerifyModalInstanceCtrl', function ($scope, $uibModalInstance, $location, columns, query, editMode) {

        $scope.query = query;
        $scope.columns = columns;
        $scope.editMode = editMode;

        $scope.saveQuery = function () {
            $scope.query.$update(function (data) {
                $location.path('/list');
                $uibModalInstance.close();
            }, function (err) {
                alert('request failed, please correct your query');
            });
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    })

;
