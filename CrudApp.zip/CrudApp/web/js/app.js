var crudApp = angular.module('crudApp', ['ngRoute', 'ngResource', 'crudApp.controllers', 'crudApp.services', 'ui.bootstrap', 'bootstrapSubmenu']);

crudApp
/*Constants regarding user login defined here*/
    .constant('USER_ROLES', {
        all: '*',
        developer: 'DEVELOPER',
        admin: 'ADMIN',
        user: 'USER'
    })
    .constant('AUTH_EVENTS', {
        loginSuccess: 'auth-login-success',
        loginFailed: 'auth-login-failed',
        logoutSuccess: 'auth-logout-success',
        sessionTimeout: 'auth-session-timeout',
        notAuthenticated: 'auth-not-authenticated',
        notAuthorized: 'auth-not-authorized'
    })
    .config(function ($httpProvider) {
        $httpProvider.interceptors.push([
            '$injector',
            function ($injector) {
                return $injector.get('AuthInterceptor');
            }
        ]);
    })
    .config(['$routeProvider', 'USER_ROLES',
        function ($routeProvider, USER_ROLES) {
            $routeProvider
                .when('/main', {
                    templateUrl: 'partials/main.html',
                    data: {
                        authorizedRoles: [USER_ROLES.developer, USER_ROLES.admin, USER_ROLES.user]
                    }
                })
                .when('/list/:groupId', {
                    templateUrl: 'partials/list.html',
                    controller: 'ListCtrl',
                    data: {
                        authorizedRoles: [USER_ROLES.developer, USER_ROLES.admin, USER_ROLES.user]
                    }
                })
                .when('/query/:id', {
                    templateUrl: 'partials/query-detail.html',
                    controller: 'EditQueryCtrl',
                    data: {
                        authorizedRoles: [USER_ROLES.developer, USER_ROLES.admin, USER_ROLES.user]
                    }
                })
                .when('/request/:queryId/', {
                    templateUrl: 'partials/request.html',
                    controller: 'CreateRequestCtrl',
                    data: {
                        authorizedRoles: [USER_ROLES.developer, USER_ROLES.admin, USER_ROLES.user]
                    }
                })
                .when('/query-request-list/:queryId', {
                    templateUrl: 'partials/queries-requests.html',
                    controller: 'ListQueriesRequestsCtrl',
                    data: {
                        authorizedRoles: [USER_ROLES.developer, USER_ROLES.admin, USER_ROLES.user]
                    }
                })
                .when('/request-detail/:queryId/:requestId', {
                    templateUrl: 'partials/submit-request.html',
                    controller: 'EditRequestCtrl'
                })
                .otherwise({
                    redirectTo: '/main',
                    data: {
                        authorizedRoles: [USER_ROLES.developer, USER_ROLES.admin, USER_ROLES.user]
                    }
                });
        }]);
