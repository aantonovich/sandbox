angular.module('crudApp.services', [])
    .factory('groupSvc', function ($resource) {
        return $resource('/api/rest/groups/:role');
    })
    .factory('queryrequestSvc', function ($resource) {
        return $resource('/api/rest/request/by-query/:queryId');
    })
    .factory('querycolumnsSvc', function ($resource) {
        return $resource('/api/rest/columns/:queryId/:id');
    })
    .factory('requestSvc', function ($resource) {
        return $resource('/api/rest/request/:requestId');
    })
    .factory('queryByGroupSvc', function ($resource) {
        return $resource('/api/rest/queries/by-group/:groupId');
    })
    .factory('querySvc', function ($resource) {
        return $resource('/api/rest/queries/:id',
            {},
            {
                'update': { method: 'PUT'},
                'verify': { method: 'PUT', url: '/api/rest/queries/verify', isArray: true }
            }
        );
    })
;