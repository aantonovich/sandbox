package com.mmc.mmcdatadump;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Created by anton.antonovich on 12.05.2016.
 */
@ApplicationPath("/rest")
public class RestApplication extends Application {

}
