package com.mmc.mmcdatadump.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlTransient;

/**
 * @author U745032
 */
@Entity
@Table(name = "MMC_DATA_DUMP_REQUEST_COLUMNS")
public class MmcDataDumpRequestColumn implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @SequenceGenerator(name = "MMC_DATA_DUMP_REQ_COLUMNS_S", sequenceName = "MMC_DATA_DUMP_REQ_COLUMNS_S", allocationSize = 1)
  @GeneratedValue(generator = "MMC_DATA_DUMP_REQ_COLUMNS_S")
  @Column(name = "REQUEST_COLUMN_ID")
  private BigDecimal requestColumnId; //--Primary key

  @ManyToOne
  @JoinColumn(name = "REQUEST_ID", referencedColumnName = "REQUEST_ID")
  @XmlTransient
  private MmcDataDumpRequest request;
  @Column(name = "COLUMN_NAME")
  private String             columnName;
  @Column(name = "USED")
  private Boolean            used;
  @Column(name = "OPERATION")
  private String             operation;
  @Column(name = "FILTER_VALUE_1")
  private String             filterValue1;
  @Column(name = "FILTER_VALUE_2")
  private String             filterValue2;

  public BigDecimal getRequestColumnId() {
    return requestColumnId;
  }

  public void setRequestColumnId(BigDecimal requestColumnId) {
    this.requestColumnId = requestColumnId;
  }

  public MmcDataDumpRequest getRequest() {
    return request;
  }

  public void setRequest(MmcDataDumpRequest request) {
    this.request = request;
  }

  public String getColumnName() {
    return columnName;
  }

  public void setColumnName(String columnName) {
    this.columnName = columnName;
  }

  public Boolean getUsed() {
    return used;
  }

  public void setUsed(Boolean used) {
    this.used = used;
  }

  public String getOperation() {
    return operation;
  }

  public void setOperation(String operation) {
    this.operation = operation;
  }

  public String getFilterValue1() {
    return filterValue1;
  }

  public void setFilterValue1(String filterValue1) {
    this.filterValue1 = filterValue1;
  }

  public String getFilterValue2() {
    return filterValue2;
  }

  public void setFilterValue2(String filterValue2) {
    this.filterValue2 = filterValue2;
  }

  @Override
  public String toString() {
    return "MmcDataDumpRequestColumn{" +
           "requestColumnId=" + requestColumnId +
           ", columnName='" + columnName + '\'' +
           ", used=" + used +
           ", operation='" + operation + '\'' +
           ", filterValue1='" + filterValue1 + '\'' +
           ", filterValue2='" + filterValue2 + '\'' +
           '}';
  }
}
