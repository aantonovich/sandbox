package com.mmc.mmcdatadump.services;

import com.mmc.mmcdatadump.model.MmcDataDumpQueryGroup;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("groups")
@Stateless
public class MmcDataDumpQueryGroupsFacadeREST {

  @PersistenceContext(name = "MMCDatasource")
  EntityManager entityManager;

  @GET
  @Path("{role}")
  @Produces(MediaType.APPLICATION_JSON)
  public List<MmcDataDumpQueryGroup> findAllTopLevelForRole(@PathParam("role") String role) {
    return entityManager.createQuery("from MmcDataDumpQueryGroup where userRole = :role").setParameter("role", role).getResultList();
  }

}
