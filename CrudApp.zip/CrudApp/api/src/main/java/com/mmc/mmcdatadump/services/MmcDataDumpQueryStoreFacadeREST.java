package com.mmc.mmcdatadump.services;

import com.mmc.mmcdatadump.model.MmcDataDumpQueryColumns;
import com.mmc.mmcdatadump.model.MmcDataDumpQueryStore;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("queries")
@Stateless
public class MmcDataDumpQueryStoreFacadeREST {

  @PersistenceContext(name = "MMCDatasource")
  EntityManager entityManager;

  @GET
  @Path("{id}")
  @Produces(MediaType.APPLICATION_JSON)
  public MmcDataDumpQueryStore find(@PathParam("id") BigDecimal id) {
    return entityManager.find(MmcDataDumpQueryStore.class, id);
  }

  @PUT
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public Response update(MmcDataDumpQueryStore query) {
    query = entityManager.merge(query);
    entityManager.createQuery("delete from MmcDataDumpQueryColumns where queryId = :queryId")
                 .setParameter("queryId", query.getQueryId()).executeUpdate();
    List<MmcDataDumpQueryColumns> mmcDataDumpQueryColumns = verify(query);
    for (MmcDataDumpQueryColumns column : mmcDataDumpQueryColumns) {
      entityManager.merge(column);
    }
    return Response.ok().build();
  }

  @PUT()
  @Path("/verify")
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public List<MmcDataDumpQueryColumns> verify(MmcDataDumpQueryStore query) {
    MmcDataDumpQueryColumns queryColumn;
    List<MmcDataDumpQueryColumns> mmcDataDumpQueryStore = new ArrayList<MmcDataDumpQueryColumns>();

    for (int i = 1; i <=10; i++) {
      queryColumn = new MmcDataDumpQueryColumns();
      queryColumn.setColumnName("Column " + i + " for query " + query.getQueryName());
      mmcDataDumpQueryStore.add(queryColumn);
    }

    return mmcDataDumpQueryStore;
  }

  @GET
  @Path("/by-group/{groupId}")
  @Produces(MediaType.APPLICATION_JSON)
  public List<MmcDataDumpQueryStore> findAllByGroup(@PathParam("groupId") BigDecimal groupId) {
    return entityManager.createQuery("from MmcDataDumpQueryStore where groupId = :groupId")
                        .setParameter("groupId", groupId).getResultList();
  }

}
