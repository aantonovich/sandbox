package com.mmc.mmcdatadump.services;

import com.mmc.mmcdatadump.model.MmcDataDumpQueryColumns;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("columns")
@Stateless
public class MmcDataDumpQueryColumnsFacadeREST {

  @PersistenceContext(name = "MMCDatasource")
  EntityManager entityManager;

  @GET
  @Path("{queryId}")
  @Produces(MediaType.APPLICATION_JSON)
  public List<MmcDataDumpQueryColumns> find(@PathParam("queryId") BigDecimal queryId) {
    return entityManager.createQuery("from MmcDataDumpQueryColumns where queryId = :queryId")
                        .setParameter("queryId", queryId).getResultList();
  }

}
