package com.mmc.mmcdatadump.services;

import com.mmc.mmcdatadump.model.MmcDataDumpRequest;
import com.mmc.mmcdatadump.model.MmcDataDumpRequestColumn;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author U745032
 */
@Path("request")
@Stateless
public class MmcDataDumpRequestFacadeREST {

  private static Map<BigDecimal, MmcDataDumpRequest> requests = new HashMap<BigDecimal, MmcDataDumpRequest>();

  @PersistenceContext(name = "MMCDatasource")
  EntityManager entityManager;

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  public Response create(MmcDataDumpRequest request) {
    entityManager.merge(request);
    entityManager.createQuery("delete from MmcDataDumpRequestColumn where request.requestId = :requestId")
                 .setParameter("requestId", request.getRequestId()).executeUpdate();
    for (MmcDataDumpRequestColumn column : request.getRequestColumns()) {
      column.setRequest(request);
      entityManager.merge(column);
    }
    return Response.ok().build();
  }

  @GET
  @Path("{requestId}")
  @Produces(MediaType.APPLICATION_JSON)
  public MmcDataDumpRequest find(@PathParam("requestId") BigDecimal requestId) {
    MmcDataDumpRequest mmcDataDumpRequest = entityManager.find(MmcDataDumpRequest.class, requestId);
    return mmcDataDumpRequest;
  }

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public List<MmcDataDumpRequest> findAll() {
    return entityManager.createQuery("from MmcDataDumpRequest").getResultList();
  }

  @GET
  @Path("/by-query/{queryId}")
  @Produces(MediaType.APPLICATION_JSON)
  public List<MmcDataDumpRequest> findByQuery(@PathParam("queryId") BigDecimal queryId) {
    return entityManager.createQuery("from MmcDataDumpRequest where queryId = :queryId")
                        .setParameter("queryId", queryId).getResultList();
  }
}
