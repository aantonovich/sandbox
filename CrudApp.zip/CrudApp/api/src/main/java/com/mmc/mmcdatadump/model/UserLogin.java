package com.mmc.mmcdatadump.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Created by anton.antonovich on 19.05.2016.
 */
@Entity
@Table(name = "MMC_DATA_DUMP_USER")
public class UserLogin {

  @Id
  @SequenceGenerator(name = "MMC_DATA_DUMP_USER_S", sequenceName = "MMC_DATA_DUMP_USER_S", allocationSize = 1)
  @GeneratedValue(generator = "MMC_DATA_DUMP_USER_S")
  @Column(name = "USER_ID")
  private BigDecimal userId;
  @Column(name = "USER_NAME")
  private String     username;
  @Column(name = "PASSWORD")
  private String     password;
  @Column(name = "USER_ROLE")
  private String     userRole;

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getUserRole() {
    return userRole;
  }

  public void setUserRole(String userRole) {
    this.userRole = userRole;
  }

  public BigDecimal getUserId() {
    return userId;
  }

  public void setUserId(BigDecimal userId) {
    this.userId = userId;
  }
}
