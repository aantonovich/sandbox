package com.mmc.mmcdatadump.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Created by anton.antonovich on 30.05.2016.
 */
@Entity
@Table(name = "MMC_DATA_DUMP_GROUP")
public class MmcDataDumpQueryGroup {

  @Id
  @SequenceGenerator(name = "MMC_DATA_DUMP_GROUP_S", sequenceName = "MMC_DATA_DUMP_GROUP_S", allocationSize = 1)
  @GeneratedValue(generator = "MMC_DATA_DUMP_GROUP_S")
  @Column(name = "GROUP_ID")
  private BigDecimal groupId;

  @Column(name = "GROUP_NAME")
  private String groupName;

  @Column(name = "USER_ROLE")
  private String userRole;

  public BigDecimal getGroupId() {
    return groupId;
  }

  public void setGroupId(BigDecimal groupId) {
    this.groupId = groupId;
  }

  public String getGroupName() {
    return groupName;
  }

  public void setGroupName(String groupName) {
    this.groupName = groupName;
  }

}
