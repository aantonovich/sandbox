package com.mmc.mmcdatadump.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Created by anton.antonovich on 30.05.2016.
 */
@Entity
@Table(name = "MMC_DATA_DUMP_SCHEMA")
public class MmcDataDumpSchema {

  @Id
  @SequenceGenerator(name = "MMC_DATA_DUMP_SCHEMA_S", sequenceName = "MMC_DATA_DUMP_SCHEMA_S", allocationSize = 1)
  @GeneratedValue(generator = "MMC_DATA_DUMP_SCHEMA_S")
  @Column(name = "SCHEMA_ID")
  private BigDecimal schemaId;

  @Column(name = "SCHEMA_NAME")
  private String schemaName;

  public BigDecimal getSchemaId() {
    return schemaId;
  }

  public void setSchemaId(BigDecimal schemaId) {
    this.schemaId = schemaId;
  }

  public String getSchemaName() {
    return schemaName;
  }

  public void setSchemaName(String schemaName) {
    this.schemaName = schemaName;
  }
}
