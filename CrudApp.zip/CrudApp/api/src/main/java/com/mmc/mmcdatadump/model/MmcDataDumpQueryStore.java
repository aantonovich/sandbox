package com.mmc.mmcdatadump.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Created by anton.antonovich on 12.05.2016.
 */
@Entity
@Table(name = "MMC_DATA_DUMP_QUERY_STORE")
public class MmcDataDumpQueryStore implements Serializable {

  @Id
  @SequenceGenerator(name = "MMC_DATA_DUMP_QUERY_STORE_S", sequenceName = "MMC_DATA_DUMP_QUERY_STORE_S", allocationSize = 1)
  @GeneratedValue(generator = "MMC_DATA_DUMP_QUERY_STORE_S")
  @Column(name = "QUERY_ID")
  private BigDecimal queryId;

  @Column(name = "GROUP_ID")
  private BigDecimal groupId;
  @Column(name = "SCHEMA_ID")
  private BigDecimal schemaId;
  @Column(name = "QUERY_NAME")
  private String     queryName;
  @Column(name = "QUERY_DESCRIPTION")
  private String     queryDescription;
  @Column(name = "FILENAME_PREFIX")
  private String     filenamePrefix;
  @Column(name = "OUT_DIRECTORY")
  private String     outDirectory;
  @Column(name = "UNIQUE_FILE_NAME")
  private Boolean     uniqueFileName;
  @Column(name = "CREATE_LOG_FILE")
  private Boolean    createLogFile;
  @Column(name = "FIELD_SEPARATOR")
  private String     fieldSeparator;
  @Column(name = "DELIVERY_METHOD")
  private String     deliveryMethod;
  @Column(name = "QUERY_TEXT")
  private String     queryText;

  public String getQueryName() {
    return queryName;
  }

  public void setQueryName(String queryName) {
    this.queryName = queryName;
  }

  public String getQueryDescription() {
    return queryDescription;
  }

  public void setQueryDescription(String queryDescription) {
    this.queryDescription = queryDescription;
  }

  public String getFilenamePrefix() {
    return filenamePrefix;
  }

  public void setFilenamePrefix(String filenamePrefix) {
    this.filenamePrefix = filenamePrefix;
  }

  public String getOutDirectory() {
    return outDirectory;
  }

  public void setOutDirectory(String outDirectory) {
    this.outDirectory = outDirectory;
  }

  public Boolean getUniqueFileName() {
    return uniqueFileName;
  }

  public void setUniqueFileName(Boolean uniqueFileName) {
    this.uniqueFileName = uniqueFileName;
  }

  public Boolean getCreateLogFile() {
    return createLogFile;
  }

  public void setCreateLogFile(Boolean createLogFile) {
    this.createLogFile = createLogFile;
  }

  public String getFieldSeparator() {
    return fieldSeparator;
  }

  public void setFieldSeparator(String fieldSeparator) {
    this.fieldSeparator = fieldSeparator;
  }

  public String getDeliveryMethod() {
    return deliveryMethod;
  }

  public void setDeliveryMethod(String deliveryMethod) {
    this.deliveryMethod = deliveryMethod;
  }

  public String getQueryText() {
    return queryText;
  }

  public void setQueryText(String queryText) {
    this.queryText = queryText;
  }

  public BigDecimal getQueryId() {
    return queryId;
  }

  public void setQueryId(BigDecimal queryId) {
    this.queryId = queryId;
  }

  public BigDecimal getGroupId() {
    return groupId;
  }

  public void setGroupId(BigDecimal groupId) {
    this.groupId = groupId;
  }

  public BigDecimal getSchemaId() {
    return schemaId;
  }

  public void setSchemaId(BigDecimal schemaId) {
    this.schemaId = schemaId;
  }

  @Override
  public String toString() {
    return "MmcDataDumpQueryStore{" +
           "queryId=" + queryId +
           ", groupId=" + groupId +
           ", schemaId=" + schemaId+
           ", queryName='" + queryName + '\'' +
           ", queryDescription='" + queryDescription + '\'' +
           ", filenamePrefix='" + filenamePrefix + '\'' +
           ", outDirectory='" + outDirectory + '\'' +
           ", uniqueFileName='" + uniqueFileName + '\'' +
           ", createLogFile=" + createLogFile +
           ", fieldSeparator='" + fieldSeparator + '\'' +
           ", deliveryMethod='" + deliveryMethod + '\'' +
           ", queryText='" + queryText + '\'' +
           '}';
  }
}
