package com.mmc.mmcdatadump.services;

import com.mmc.mmcdatadump.model.UserLogin;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Created by anton.antonovich on 19.05.2016.
 */
@Path("login")
@Stateless
public class UserLoginFacadeREST {

  @PersistenceContext(name = "MMCDatasource")
  EntityManager entityManager;

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response login(UserLogin user) {
    List users = entityManager.createQuery("from UserLogin where username = :username")
                              .setParameter("username", user.getUsername()).setMaxResults(1)
                              .getResultList();
    if (!users.isEmpty()) {
      UserLogin loadedUser = (UserLogin) users.get(0);
      if (loadedUser.getPassword().equals(user.getPassword())) {
        return Response.ok(loadedUser).build();
      }

    }
    return Response.status(Response.Status.FORBIDDEN).build();
  }
}
