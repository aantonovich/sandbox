package com.mmc.mmcdatadump.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author U745032
 */
@Entity
@Table(name = "MMC_DATA_DUMP_REQUEST")
public class MmcDataDumpRequest implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @SequenceGenerator(name = "MMC_DATA_DUMP_REQUEST_S", sequenceName = "MMC_DATA_DUMP_REQUEST_S", allocationSize = 1)
  @GeneratedValue(generator = "MMC_DATA_DUMP_REQUEST_S")
  @Column(name = "REQUEST_ID")
  private BigDecimal requestId; //--Primary key

  @Column(name = "QUERY_ID")
  private BigDecimal queryId;
  @Column(name = "USER_NAME")
  private String     userName;
  @Column(name = "SCHEDULE_DATE")
  private Date       scheduleDate;
  @Column(name = "FIELD_SEPARATOR")
  private String     fieldSeparator;
  @Column(name = "FILENAME_PREFIX")
  private String     filenamePrefix;
  @Column(name = "OUT_DIRECTORY")
  private String     outDirectory;
  @Column(name = "UNIQUE_FILE_NAME")
  private String     uniqueFileName;
  @Column(name = "CREATE_LOG_FILE")
  private Boolean    createLogFile;
  @OneToMany(mappedBy = "request", fetch = FetchType.EAGER)
  private List<MmcDataDumpRequestColumn> requestColumns = new ArrayList<MmcDataDumpRequestColumn>();

  public BigDecimal getRequestId() {
    return requestId;
  }

  public void setRequestId(BigDecimal requestId) {
    this.requestId = requestId;
  }

  public BigDecimal getQueryId() {
    return queryId;
  }

  public void setQueryId(BigDecimal queryId) {
    this.queryId = queryId;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public Date getScheduleDate() {
    return scheduleDate;
  }

  public void setScheduleDate(Date scheduleDate) {
    this.scheduleDate = scheduleDate;
  }

  public String getFieldSeparator() {
    return fieldSeparator;
  }

  public void setFieldSeparator(String fieldSeparator) {
    this.fieldSeparator = fieldSeparator;
  }

  public String getFilenamePrefix() {
    return filenamePrefix;
  }

  public void setFilenamePrefix(String filenamePrefix) {
    this.filenamePrefix = filenamePrefix;
  }

  public String getOutDirectory() {
    return outDirectory;
  }

  public void setOutDirectory(String outDirectory) {
    this.outDirectory = outDirectory;
  }

  public String getUniqueFileName() {
    return uniqueFileName;
  }

  public void setUniqueFileName(String uniqueFileName) {
    this.uniqueFileName = uniqueFileName;
  }

  public Boolean getCreateLogFile() {
    return createLogFile;
  }

  public void setCreateLogFile(Boolean createLogFile) {
    this.createLogFile = createLogFile;
  }

  public List<MmcDataDumpRequestColumn> getRequestColumns() {
    return requestColumns;
  }

  public void setRequestColumns(
      List<MmcDataDumpRequestColumn> requestColumns) {
    this.requestColumns = requestColumns;
  }

  @Override
  public String toString() {
    return "MmcDataDumpRequest{" +
           "requestId=" + requestId +
           ", queryId=" + queryId +
           ", userName='" + userName + '\'' +
           ", scheduleDate=" + scheduleDate +
           ", fieldSeparator='" + fieldSeparator + '\'' +
           ", filenamePrefix='" + filenamePrefix + '\'' +
           ", outDirectory='" + outDirectory + '\'' +
           ", uniqueFileName='" + uniqueFileName + '\'' +
           ", createLogFile=" + createLogFile +
           ", requestColumns=" + requestColumns +
           '}';
  }
}
