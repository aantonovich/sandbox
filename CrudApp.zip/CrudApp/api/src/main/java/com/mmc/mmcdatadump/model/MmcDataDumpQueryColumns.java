package com.mmc.mmcdatadump.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Created by anton.antonovich on 12.05.2016.
 */
@Entity
@Table(name = "MMC_DATA_DUMP_QUERY_COLUMNS")
public class MmcDataDumpQueryColumns implements Serializable {

  @Id
  @SequenceGenerator(name = "MMC_DATA_DUMP_QUERY_COLUMNS_S", sequenceName = "MMC_DATA_DUMP_QUERY_COLUMNS_S", allocationSize = 1)
  @GeneratedValue(generator = "MMC_DATA_DUMP_QUERY_COLUMNS_S")
  @Column(name = "COLUMN_ID")
  private BigDecimal columnId;
  @Column(name = "QUERY_ID")
  private BigDecimal queryId;
  @Column(name = "COLUMN_NAME")
  private String     columnName;
  @Column(name = "COLUMN_TYPE")
  private String     columnType;

  public BigDecimal getColumnId() {
    return columnId;
  }

  public void setColumnId(BigDecimal columnId) {
    this.columnId = columnId;
  }

  public BigDecimal getQueryId() {
    return queryId;
  }

  public void setQueryId(BigDecimal queryId) {
    this.queryId = queryId;
  }

  public String getColumnName() {
    return columnName;
  }

  public void setColumnName(String columnName) {
    this.columnName = columnName;
  }

  public String getColumnType() {
    return columnType;
  }

  public void setColumnType(String columnType) {
    this.columnType = columnType;
  }
}
