package com;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.util.Locale;

public class StatementsRunner {

  public static void main(String[] args) throws Exception {
    Locale.setDefault(Locale.ENGLISH);
    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE", "anton", "anton");

    CallableStatement stmt = connection.prepareCall("{call sys.dbms_output.enable(?) }");
    stmt.setInt(1,1000);
    stmt.execute();

    CallableStatement statement =
        connection.prepareCall("{call MMC_DATA_DUMP.SUBMIT_REQUEST(" +
                               "p_query_name        => ?" +
                               "    , p_select => ?" +
                               "    ,p_where => ?" +
                               "    ,p_user_name         => ?" +
                               "    ,p_schedule_date     => ?" +
                               "    ,p_field_separator   => ?" +
                               "    ,p_filename_prefix   => ?" +
                               "    ,p_out_directory     => ?" +
                               "    ,p_delivery_method   => ?" +
                               "    ,p_unique_filename   => ?" +
                               "    ,p_create_log_file   => ?" +
                               "    ,p_out=>?" +
                               ")}");

    statement.setString(1, "Query Name2");
    statement.setString(2, "'COLUMN_TYPE', 'COLUMN_NAME' ");
    statement.setString(3, "'COLUMN_TYPE'='Type1' AND 'COLUMN_NAME'='Name1'");
    statement.setString(4, "user1");
    statement.setDate(5, new Date(new java.util.Date().getTime()));
    statement.setString(6, "~");
    statement.setString(7, "Rick2");
    statement.setString(8, "FOO_DIR");
    statement.setString(9, "DelFile3");
    statement.setString(10, "Y");
    statement.setString(11, "N");
    statement.registerOutParameter(12, java.sql.Types.VARCHAR);

    try {
      statement.executeUpdate();
      System.out.println(statement.getString(11));
    } catch (Exception e) {
      e.printStackTrace();
    }

    stmt = connection.prepareCall("{call sys.dbms_output.get_line(?,?)}");
    stmt.registerOutParameter(1,java.sql.Types.VARCHAR);
    stmt.registerOutParameter(2,java.sql.Types.NUMERIC);
    int status;
    do {
      stmt.execute();
      System.out.println(" "+stmt.getString(1));
      status = stmt.getInt(2);
    } while (status == 0);
    System.out.println("End of dbms_output!");
  }

}
